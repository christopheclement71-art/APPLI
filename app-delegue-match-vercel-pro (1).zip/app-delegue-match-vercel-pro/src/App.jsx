import { useEffect, useMemo, useState } from 'react'
import {
  AlertTriangle,
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  Download,
  FileText,
  Goal,
  LayoutDashboard,
  ListChecks,
  Plus,
  RefreshCw,
  Save,
  ShieldCheck,
  Siren,
  Trash2,
  Users,
} from 'lucide-react'

const STORAGE_KEY = 'delegue-match-pro-v2'

const defaultChecklist = [
  'Terrain vérifié',
  'Vestiaires ouverts',
  'Présence des secours',
  'Présence du médecin / infirmier',
  'Forces de sécurité informées',
  'Contrôle des équipements',
  'Licences / identités contrôlées',
  'Feuille de match validée',
  'Ballons réglementaires disponibles',
  'Éclairage vérifié',
  'Sono / affichage OK',
  'Accès arbitres sécurisé',
]

const emptyIncident = {
  minute: '',
  type: 'Incident',
  equipe: 'Domicile',
  description: '',
  gravite: 'Moyenne',
}

const emptyEvent = {
  minute: '',
  type: 'But',
  equipe: 'Domicile',
  joueur: '',
  detail: '',
}

function makePlayers(prefix) {
  return Array.from({ length: 16 }, (_, index) => ({
    numero: index < 11 ? String(index + 1) : '',
    nom: `${prefix} joueur ${index + 1}`,
    titulaire: index < 11,
    capitaine: index === 0,
  }))
}

const initialState = {
  organization: {
    competition: 'Championnat régional',
    journee: '18',
    date: '',
    heure: '',
    stade: '',
    ville: '',
    domicile: 'FC Domicile',
    exterieur: 'US Extérieur',
    scoreDomicile: '',
    scoreExterieur: '',
    affluence: '',
    meteo: '',
    delegue: '',
    observateur: '',
    arbitreCentral: '',
    arbitre1: '',
    arbitre2: '',
    quatrieme: '',
    logoText: 'LIGUE / CLUB',
  },
  checklist: defaultChecklist.map((label) => ({ label, done: false })),
  teamHome: makePlayers('Domicile'),
  teamAway: makePlayers('Extérieur'),
  incidents: [],
  events: [],
  report: {
    avantMatch: '',
    pendantMatch: '',
    apresMatch: '',
    observations: '',
    recommandation: 'RAS',
  },
  signatures: {
    delegueNom: '',
    delegueSignature: '',
    responsableNom: '',
    responsableSignature: '',
  },
}

function Card({ children, className = '' }) {
  return <section className={`card ${className}`}>{children}</section>
}

function SectionTitle({ icon: Icon, title, subtitle }) {
  return (
    <div className="section-title">
      <div className="icon-pill"><Icon size={20} /></div>
      <div>
        <h2>{title}</h2>
        {subtitle ? <p>{subtitle}</p> : null}
      </div>
    </div>
  )
}

function Field({ label, children }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  )
}

function TabButton({ active, onClick, children }) {
  return (
    <button className={`tab-btn ${active ? 'active' : ''}`} onClick={onClick}>
      {children}
    </button>
  )
}

function StatCard({ label, value, hint }) {
  return (
    <Card className="stat-card">
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      {hint ? <div className="stat-hint">{hint}</div> : null}
    </Card>
  )
}

function TeamSheet({ title, players, setPlayers }) {
  function updatePlayer(index, key, value) {
    setPlayers((prev) => prev.map((p, i) => (i === index ? { ...p, [key]: value } : p)))
  }

  function resetTeamNames() {
    setPlayers((prev) =>
      prev.map((p, i) => ({
        ...p,
        nom: '',
        numero: i < 11 ? String(i + 1) : '',
        titulaire: i < 11,
        capitaine: i === 0,
      })),
    )
  }

  return (
    <Card>
      <div className="row-between">
        <SectionTitle icon={Users} title={title} subtitle="Titulaire, remplaçants, capitaine" />
        <button className="ghost-btn" onClick={resetTeamNames}>Réinitialiser</button>
      </div>
      <div className="table-scroll">
        <table className="data-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Nom</th>
              <th>Titulaire</th>
              <th>Capitaine</th>
            </tr>
          </thead>
          <tbody>
            {players.map((player, index) => (
              <tr key={index}>
                <td>
                  <input value={player.numero} onChange={(e) => updatePlayer(index, 'numero', e.target.value)} />
                </td>
                <td>
                  <input value={player.nom} onChange={(e) => updatePlayer(index, 'nom', e.target.value)} />
                </td>
                <td className="center-cell">
                  <input
                    type="checkbox"
                    checked={player.titulaire}
                    onChange={(e) => updatePlayer(index, 'titulaire', e.target.checked)}
                  />
                </td>
                <td className="center-cell">
                  <input
                    type="radio"
                    name={title}
                    checked={player.capitaine}
                    onChange={() =>
                      setPlayers((prev) => prev.map((p, i) => ({ ...p, capitaine: i === index })))
                    }
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  )
}

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [state, setState] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (!saved) return initialState
    try {
      return JSON.parse(saved)
    } catch {
      return initialState
    }
  })

  const [newIncident, setNewIncident] = useState(emptyIncident)
  const [newEvent, setNewEvent] = useState(emptyEvent)
  const [saveMessage, setSaveMessage] = useState('')

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    setSaveMessage('Sauvegarde automatique activée')
    const timer = setTimeout(() => setSaveMessage(''), 1800)
    return () => clearTimeout(timer)
  }, [state])

  const checklistDone = state.checklist.filter((item) => item.done).length
  const scoreFromEvents = useMemo(() => {
    const home = state.events.filter((e) => e.type === 'But' && e.equipe === 'Domicile').length
    const away = state.events.filter((e) => e.type === 'But' && e.equipe === 'Extérieur').length
    return { home, away }
  }, [state.events])

  const totalTitularHome = state.teamHome.filter((p) => p.titulaire).length
  const totalTitularAway = state.teamAway.filter((p) => p.titulaire).length
  const incidentsGraves = state.incidents.filter((i) => i.gravite === 'Élevée').length

  const summary = useMemo(() => {
    const o = state.organization
    const officialScoreHome = o.scoreDomicile || String(scoreFromEvents.home || 0)
    const officialScoreAway = o.scoreExterieur || String(scoreFromEvents.away || 0)

    const listPlayers = (label, players) => {
      const titulaires = players.filter((p) => p.titulaire).map((p) => `${p.numero || '-'} ${p.nom}${p.capitaine ? ' (C)' : ''}`).join(', ')
      const rempla = players.filter((p) => !p.titulaire).map((p) => `${p.numero || '-'} ${p.nom}`).join(', ')
      return `${label}\n- Titulaires : ${titulaires || '-'}\n- Remplaçants : ${rempla || '-'}`
    }

    return `RAPPORT DÉLÉGUÉ DE MATCH

Compétition : ${o.competition}
Journée : ${o.journee}
Date : ${o.date || '-'} ${o.heure || ''}
Lieu : ${o.stade || '-'}, ${o.ville || '-'}
Match : ${o.domicile} vs ${o.exterieur}
Score : ${officialScoreHome} - ${officialScoreAway}
Affluence : ${o.affluence || '-'}
Météo : ${o.meteo || '-'}

OFFICIELS
- Délégué : ${o.delegue || '-'}
- Observateur : ${o.observateur || '-'}
- Arbitre central : ${o.arbitreCentral || '-'}
- Assistant 1 : ${o.arbitre1 || '-'}
- Assistant 2 : ${o.arbitre2 || '-'}
- 4e arbitre : ${o.quatrieme || '-'}

CHECKLIST
- Points validés : ${checklistDone}/${state.checklist.length}

COMPOSITIONS
${listPlayers(o.domicile, state.teamHome)}

${listPlayers(o.exterieur, state.teamAway)}

ÉVÉNEMENTS SPORTIFS
${state.events.length ? state.events.map((e, idx) => `${idx + 1}. ${e.minute}' | ${e.type} | ${e.equipe} | ${e.joueur || '-'} | ${e.detail || '-'}`).join('\n') : 'Aucun événement sportif saisi'}

INCIDENTS
${state.incidents.length ? state.incidents.map((i, idx) => `${idx + 1}. ${i.minute}' | ${i.type} | ${i.equipe} | Gravité: ${i.gravite} | ${i.description}`).join('\n') : 'Aucun incident signalé'}

AVANT-MATCH
${state.report.avantMatch || '-'}

PENDANT LE MATCH
${state.report.pendantMatch || '-'}

APRÈS-MATCH
${state.report.apresMatch || '-'}

OBSERVATIONS GÉNÉRALES
${state.report.observations || '-'}

RECOMMANDATION
${state.report.recommandation || '-'}

SIGNATURES
- Délégué : ${state.signatures.delegueNom || '-'} / ${state.signatures.delegueSignature || '-'}
- Responsable club : ${state.signatures.responsableNom || '-'} / ${state.signatures.responsableSignature || '-'}`
  }, [state, checklistDone, scoreFromEvents])

  function updateOrganization(key, value) {
    setState((prev) => ({ ...prev, organization: { ...prev.organization, [key]: value } }))
  }

  function updateReport(key, value) {
    setState((prev) => ({ ...prev, report: { ...prev.report, [key]: value } }))
  }

  function updateSignature(key, value) {
    setState((prev) => ({ ...prev, signatures: { ...prev.signatures, [key]: value } }))
  }

  function addIncident() {
    if (!newIncident.minute.trim() || !newIncident.description.trim()) return
    setState((prev) => ({ ...prev, incidents: [...prev.incidents, newIncident] }))
    setNewIncident(emptyIncident)
  }

  function addEvent() {
    if (!newEvent.minute.trim() || !newEvent.type.trim()) return
    setState((prev) => ({ ...prev, events: [...prev.events, newEvent] }))
    setNewEvent(emptyEvent)
  }

  function exportTxt() {
    const blob = new Blob([summary], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'rapport-delegue-pro.txt'
    a.click()
    URL.revokeObjectURL(url)
  }

  function printPdf() {
    window.print()
  }

  function resetAll() {
    if (!window.confirm('Réinitialiser toutes les données ?')) return
    localStorage.removeItem(STORAGE_KEY)
    setState(initialState)
    setNewEvent(emptyEvent)
    setNewIncident(emptyIncident)
  }

  return (
    <div className="app-shell">
      <div className="container">
        <header className="hero">
          <div className="hero-left">
            <div className="logo-box">{state.organization.logoText}</div>
            <div>
              <div className="eyebrow">Version pro prête pour Vercel</div>
              <h1>Délégué de match de football</h1>
              <p>Suivi complet du match, feuille de composition, événements, incidents, signatures et export impression PDF.</p>
            </div>
          </div>
          <div className="hero-actions">
            <button className="ghost-btn" onClick={resetAll}><RefreshCw size={16} /> Réinitialiser</button>
            <button className="ghost-btn" onClick={printPdf}><FileText size={16} /> Export PDF</button>
            <button className="primary-btn" onClick={exportTxt}><Download size={18} /> Export TXT</button>
          </div>
        </header>

        <div className="save-banner">{saveMessage || 'Données sauvegardées localement sur cet appareil'}</div>

        <div className="stats-grid">
          <StatCard label="Checklist" value={`${checklistDone}/${state.checklist.length}`} hint="Contrôles validés" />
          <StatCard label="Score live" value={`${scoreFromEvents.home} - ${scoreFromEvents.away}`} hint="Calculé depuis les buts" />
          <StatCard label="Incidents graves" value={incidentsGraves} hint="À surveiller" />
          <StatCard label="Titulaires" value={`${totalTitularHome} / ${totalTitularAway}`} hint="Domicile / Extérieur" />
        </div>

        <div className="tabs no-print">
          <TabButton active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')}>Tableau de bord</TabButton>
          <TabButton active={activeTab === 'match'} onClick={() => setActiveTab('match')}>Match</TabButton>
          <TabButton active={activeTab === 'equipes'} onClick={() => setActiveTab('equipes')}>Équipes</TabButton>
          <TabButton active={activeTab === 'evenements'} onClick={() => setActiveTab('evenements')}>Événements</TabButton>
          <TabButton active={activeTab === 'incidents'} onClick={() => setActiveTab('incidents')}>Incidents</TabButton>
          <TabButton active={activeTab === 'rapport'} onClick={() => setActiveTab('rapport')}>Rapport</TabButton>
          <TabButton active={activeTab === 'signatures'} onClick={() => setActiveTab('signatures')}>Signatures</TabButton>
          <TabButton active={activeTab === 'resume'} onClick={() => setActiveTab('resume')}>Résumé</TabButton>
        </div>

        {activeTab === 'dashboard' && (
          <div className="dashboard-grid">
            <Card>
              <SectionTitle icon={LayoutDashboard} title="Vue rapide" subtitle="Les points clés du match" />
              <div className="quick-list">
                <div><strong>Match :</strong> {state.organization.domicile} vs {state.organization.exterieur}</div>
                <div><strong>Lieu :</strong> {state.organization.stade || '-'} - {state.organization.ville || '-'}</div>
                <div><strong>Date :</strong> {state.organization.date || '-'} {state.organization.heure || ''}</div>
                <div><strong>Officiels :</strong> {state.organization.arbitreCentral || '-'} / {state.organization.delegue || '-'}</div>
              </div>
            </Card>
            <Card>
              <SectionTitle icon={ListChecks} title="Checklist" subtitle="Contrôle avant-match" />
              <div className="mini-list">
                {state.checklist.map((item, i) => (
                  <label className="check-item" key={i}>
                    <input
                      type="checkbox"
                      checked={item.done}
                      onChange={(e) =>
                        setState((prev) => ({
                          ...prev,
                          checklist: prev.checklist.map((entry, index) =>
                            index === i ? { ...entry, done: e.target.checked } : entry,
                          ),
                        }))
                      }
                    />
                    <span>{item.label}</span>
                  </label>
                ))}
              </div>
            </Card>
            <Card>
              <SectionTitle icon={AlertTriangle} title="Alerte incidents" subtitle="Journal rapide" />
              <div className="stack-list">
                {state.incidents.length === 0 ? <div className="empty-box">Aucun incident</div> :
                  state.incidents.slice(-5).reverse().map((i, idx) => (
                    <div className="timeline-item" key={idx}>
                      <strong>{i.minute}'</strong> - {i.type} - {i.equipe}
                      <div className="muted">{i.description}</div>
                    </div>
                  ))
                }
              </div>
            </Card>
          </div>
        )}

        {activeTab === 'match' && (
          <Card>
            <SectionTitle icon={CalendarDays} title="Informations du match" subtitle="Données générales et officiels" />
            <div className="form-grid">
              {[
                ['competition', 'Compétition', 'text'],
                ['journee', 'Journée', 'text'],
                ['date', 'Date', 'date'],
                ['heure', 'Heure', 'time'],
                ['stade', 'Stade', 'text'],
                ['ville', 'Ville', 'text'],
                ['domicile', 'Équipe domicile', 'text'],
                ['exterieur', 'Équipe extérieure', 'text'],
                ['scoreDomicile', 'Score domicile', 'number'],
                ['scoreExterieur', 'Score extérieur', 'number'],
                ['affluence', 'Affluence', 'number'],
                ['meteo', 'Météo', 'text'],
                ['delegue', 'Délégué', 'text'],
                ['observateur', 'Observateur', 'text'],
                ['arbitreCentral', 'Arbitre central', 'text'],
                ['arbitre1', 'Assistant 1', 'text'],
                ['arbitre2', 'Assistant 2', 'text'],
                ['quatrieme', '4e arbitre', 'text'],
                ['logoText', 'Texte logo / entête', 'text'],
              ].map(([key, label, type]) => (
                <Field key={key} label={label}>
                  <input type={type} value={state.organization[key]} onChange={(e) => updateOrganization(key, e.target.value)} />
                </Field>
              ))}
            </div>
          </Card>
        )}

        {activeTab === 'equipes' && (
          <div className="two-col">
            <TeamSheet title={state.organization.domicile || 'Équipe domicile'} players={state.teamHome} setPlayers={(teamHome) => setState((prev) => ({ ...prev, teamHome }))} />
            <TeamSheet title={state.organization.exterieur || 'Équipe extérieure'} players={state.teamAway} setPlayers={(teamAway) => setState((prev) => ({ ...prev, teamAway }))} />
          </div>
        )}

        {activeTab === 'evenements' && (
          <div className="two-col">
            <Card>
              <SectionTitle icon={Goal} title="Ajouter un événement sportif" subtitle="Buts, cartons, remplacements" />
              <div className="form-grid compact">
                <Field label="Minute"><input value={newEvent.minute} onChange={(e) => setNewEvent((v) => ({ ...v, minute: e.target.value }))} /></Field>
                <Field label="Type">
                  <select value={newEvent.type} onChange={(e) => setNewEvent((v) => ({ ...v, type: e.target.value }))}>
                    <option>But</option>
                    <option>Carton jaune</option>
                    <option>Carton rouge</option>
                    <option>Remplacement</option>
                    <option>Pénalty</option>
                    <option>Blessure</option>
                  </select>
                </Field>
                <Field label="Équipe">
                  <select value={newEvent.equipe} onChange={(e) => setNewEvent((v) => ({ ...v, equipe: e.target.value }))}>
                    <option>Domicile</option>
                    <option>Extérieur</option>
                  </select>
                </Field>
                <Field label="Joueur"><input value={newEvent.joueur} onChange={(e) => setNewEvent((v) => ({ ...v, joueur: e.target.value }))} /></Field>
              </div>
              <Field label="Détail">
                <textarea value={newEvent.detail} onChange={(e) => setNewEvent((v) => ({ ...v, detail: e.target.value }))} />
              </Field>
              <button className="primary-btn" onClick={addEvent}><Plus size={16} /> Ajouter</button>
            </Card>

            <Card>
              <SectionTitle icon={CheckCircle2} title="Feuille d'événements" subtitle="Journal chronologique" />
              <div className="stack-list">
                {state.events.length === 0 ? <div className="empty-box">Aucun événement saisi</div> :
                  state.events.map((event, index) => (
                    <div className="timeline-item" key={index}>
                      <div className="row-between">
                        <div><strong>{event.minute}'</strong> - {event.type} - {event.equipe}</div>
                        <button className="icon-btn" onClick={() => setState((prev) => ({ ...prev, events: prev.events.filter((_, i) => i !== index) }))}><Trash2 size={16} /></button>
                      </div>
                      <div className="muted">{event.joueur || '-'} {event.detail ? `• ${event.detail}` : ''}</div>
                    </div>
                  ))
                }
              </div>
            </Card>
          </div>
        )}

        {activeTab === 'incidents' && (
          <div className="two-col">
            <Card>
              <SectionTitle icon={Siren} title="Ajouter un incident" subtitle="Traçabilité sécurité / organisation" />
              <div className="form-grid compact">
                <Field label="Minute"><input value={newIncident.minute} onChange={(e) => setNewIncident((v) => ({ ...v, minute: e.target.value }))} /></Field>
                <Field label="Type">
                  <select value={newIncident.type} onChange={(e) => setNewIncident((v) => ({ ...v, type: e.target.value }))}>
                    <option>Incident</option>
                    <option>Retard</option>
                    <option>Envahissement</option>
                    <option>Sécurité</option>
                    <option>Protestation</option>
                    <option>Interruption</option>
                  </select>
                </Field>
                <Field label="Équipe / zone">
                  <select value={newIncident.equipe} onChange={(e) => setNewIncident((v) => ({ ...v, equipe: e.target.value }))}>
                    <option>Domicile</option>
                    <option>Extérieur</option>
                    <option>Tribune</option>
                    <option>Arbitrage</option>
                    <option>Organisation</option>
                  </select>
                </Field>
                <Field label="Gravité">
                  <select value={newIncident.gravite} onChange={(e) => setNewIncident((v) => ({ ...v, gravite: e.target.value }))}>
                    <option>Faible</option>
                    <option>Moyenne</option>
                    <option>Élevée</option>
                  </select>
                </Field>
              </div>
              <Field label="Description">
                <textarea value={newIncident.description} onChange={(e) => setNewIncident((v) => ({ ...v, description: e.target.value }))} />
              </Field>
              <button className="primary-btn" onClick={addIncident}><Plus size={16} /> Ajouter</button>
            </Card>

            <Card>
              <SectionTitle icon={AlertTriangle} title="Registre des incidents" subtitle="À joindre au rapport" />
              <div className="stack-list">
                {state.incidents.length === 0 ? <div className="empty-box">Aucun incident saisi</div> :
                  state.incidents.map((incident, index) => (
                    <div className="timeline-item" key={index}>
                      <div className="row-between">
                        <div><strong>{incident.minute}'</strong> - {incident.type} - {incident.equipe} - {incident.gravite}</div>
                        <button className="icon-btn" onClick={() => setState((prev) => ({ ...prev, incidents: prev.incidents.filter((_, i) => i !== index) }))}><Trash2 size={16} /></button>
                      </div>
                      <div className="muted">{incident.description}</div>
                    </div>
                  ))
                }
              </div>
            </Card>
          </div>
        )}

        {activeTab === 'rapport' && (
          <Card>
            <SectionTitle icon={ClipboardList} title="Rédaction du rapport" subtitle="Synthèse officielle" />
            <div className="form-grid compact">
              <Field label="Avant-match"><textarea value={state.report.avantMatch} onChange={(e) => updateReport('avantMatch', e.target.value)} /></Field>
              <Field label="Pendant le match"><textarea value={state.report.pendantMatch} onChange={(e) => updateReport('pendantMatch', e.target.value)} /></Field>
              <Field label="Après-match"><textarea value={state.report.apresMatch} onChange={(e) => updateReport('apresMatch', e.target.value)} /></Field>
              <Field label="Observations générales"><textarea value={state.report.observations} onChange={(e) => updateReport('observations', e.target.value)} /></Field>
            </div>
            <Field label="Recommandation finale">
              <textarea value={state.report.recommandation} onChange={(e) => updateReport('recommandation', e.target.value)} />
            </Field>
          </Card>
        )}

        {activeTab === 'signatures' && (
          <Card>
            <SectionTitle icon={Save} title="Signatures" subtitle="Zone de validation finale" />
            <div className="form-grid compact">
              <Field label="Nom du délégué"><input value={state.signatures.delegueNom} onChange={(e) => updateSignature('delegueNom', e.target.value)} /></Field>
              <Field label="Signature du délégué"><input value={state.signatures.delegueSignature} onChange={(e) => updateSignature('delegueSignature', e.target.value)} placeholder="Ex: signé électroniquement" /></Field>
              <Field label="Nom responsable club"><input value={state.signatures.responsableNom} onChange={(e) => updateSignature('responsableNom', e.target.value)} /></Field>
              <Field label="Signature responsable club"><input value={state.signatures.responsableSignature} onChange={(e) => updateSignature('responsableSignature', e.target.value)} /></Field>
            </div>
          </Card>
        )}

        {activeTab === 'resume' && (
          <Card className="print-card">
            <SectionTitle icon={FileText} title="Résumé final" subtitle="Version imprimable / PDF" />
            <pre className="summary-box">{summary}</pre>
          </Card>
        )}
      </div>
    </div>
  )
}
