# App Délégué de Match Pro - Vercel

Version améliorée prête à déployer sur Vercel.

## Inclus
- tableau de bord
- fiche match complète
- compositions des 2 équipes
- événements sportifs : buts, cartons, remplacements
- incidents
- rapport officiel
- signatures
- sauvegarde automatique locale
- export TXT
- export PDF via impression navigateur

## Lancer en local
```bash
npm install
npm run dev
```

## Déployer sur Vercel
1. Décompresser le ZIP
2. Envoyer le dossier sur GitHub
3. Importer le dépôt dans Vercel
4. Déployer

## Paramètres Vercel
- Framework preset : Vite
- Build command : npm run build
- Output directory : dist

## Suite possible
Cette version n'utilise pas encore de backend.
Pour une vraie version production, on peut ajouter ensuite :
- connexion utilisateur
- Supabase ou Firebase
- base de données des matchs
- stockage cloud
- PDF officiel avec mise en page ligue / district
- rôles : délégué, arbitre, secrétaire, admin
